package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Esta clase representa la relación de seguimiento entre dos cuentas de usuario.
 */
public class CuentaSigueCuenta {
	
	private int idSeguido;
	private int idSeguidor;
	private LocalDate fecha;
	
	/**
	 * Constructor por defecto de la clase.
	 */
	public CuentaSigueCuenta() {}

	/**
	 * Constructor de la clase que inicializa los identificadores de las cuentas seguidas y seguidoras, y establece la fecha actual.
	 * @param idSeguido El identificador de la cuenta seguida.
	 * @param idSeguidor El identificador de la cuenta seguidora.
	 */
	public CuentaSigueCuenta(int idSeguido, int idSeguidor) {
	
		this.idSeguido = idSeguido;
		this.idSeguidor = idSeguidor;
		this.fecha = LocalDate.now();
	}

	/**
	 * Obtiene el identificador de la cuenta seguida.
	 * @return El identificador de la cuenta seguida.
	 */
	public int getIdSeguido() {
		return idSeguido;
	}

	/**
	 * Establece el identificador de la cuenta seguida.
	 * @param idSeguido El identificador de la cuenta seguida.
	 */
	public void setIdSeguido(int idSeguido) {
		this.idSeguido = idSeguido;
	}

	/**
	 * Obtiene el identificador de la cuenta seguidora.
	 * @return El identificador de la cuenta seguidora.
	 */
	public int getIdSeguidor() {
		return idSeguidor;
	}

	/**
	 * Establece el identificador de la cuenta seguidora.
	 * @param idSeguidor El identificador de la cuenta seguidora.
	 */
	public void setIdSeguidor(int idSeguidor) {
		this.idSeguidor = idSeguidor;
	}

	/**
	 * Obtiene la fecha en que se realizó el seguimiento.
	 * @return La fecha en que se realizó el seguimiento.
	 */
	public LocalDate getFecha() {
		return fecha;
	}

	/**
	 * Establece la fecha en que se realizó el seguimiento.
	 * @param fecha La fecha en que se realizó el seguimiento, en formato "yyyy-MM-dd".
	 */
	public void setFecha(String fecha) {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		this.fecha = LocalDate.parse(fecha,f);
	}

	/**
	 * Devuelve una representación en forma de cadena de la relación de seguimiento entre dos cuentas.
	 * @return Una cadena que representa la relación de seguimiento entre dos cuentas.
	 */
	@Override
	public String toString() {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return "CuentaSigueCuenta [idSeguido=" + idSeguido + ", idSeguidor=" + idSeguidor + ", fecha=" + f.format(fecha) + "]";
	}
}
