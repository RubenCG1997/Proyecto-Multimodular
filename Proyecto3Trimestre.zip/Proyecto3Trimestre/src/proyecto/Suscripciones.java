package proyecto;

/**
 * La clase Suscripciones representa los distintos tipos de suscripciones disponibles para usuarios.
 * Permite definir el tipo de suscripción (individual, dúo o familiar) y la modalidad de cuota (mensual o anual).
 * Además, calcula automáticamente el precio de la suscripción en función del tipo y la cuota seleccionados.
 */
public class Suscripciones {
	
	// Enumeraciones para los tipos de suscripción y las modalidades de cuota
	enum TIPO {
		INDIVIDUAL, DUO, FAMILIAR;
	}
	enum CUOTA {
		MENSUAL, ANUAL;
	}
	
	// Atributos
	private TIPO tipo; // El tipo de suscripción
	private CUOTA cuota; // La modalidad de cuota (mensual o anual)
	private double precio; // El precio de la suscripción

	/**
	 * Constructor por defecto de la clase Suscripciones.
	 */
	public Suscripciones() {
	}

	/**
	 * Constructor de la clase Suscripciones con parámetros.
	 * 
	 * @param tipo el tipo de suscripción
	 * @param cuota la modalidad de cuota (mensual o anual)
	 */
	public Suscripciones(TIPO tipo, CUOTA cuota) {
		this.tipo = tipo;
		this.cuota = cuota;
		this.precio = calcularPrecio();
	}

	// Métodos de acceso y modificación
	
	public TIPO getTipo() {
		return tipo;
	}

	public void setTipo(TIPO tipo) {
		this.tipo = tipo;
	}

	public CUOTA getCuota() {
		return cuota;
	}

	public void setCuota(CUOTA cuota) {
		this.cuota = cuota;
	}

	/**
	 * Obtiene el precio de la suscripción.
	 * 
	 * @return el precio de la suscripción
	 */
	public double getPrecio() {
		return calcularPrecio();
	}
	
	@Override
	public String toString() {
		return "Suscripciones [tipo=" + tipo + ", cuota=" + cuota + ", precio=" + precio + "]";
	}

	/**
	 * Calcula el precio de la suscripción en función del tipo y la cuota seleccionados.
	 * 
	 * @return el precio de la suscripción calculado
	 */
	private double calcularPrecio() {

		if (this.tipo == TIPO.INDIVIDUAL && this.cuota == CUOTA.MENSUAL) {
			this.precio = 8.99;
		} else if (this.tipo == TIPO.INDIVIDUAL && this.cuota == CUOTA.ANUAL) {
			this.precio = 89.99;
		} else if (this.tipo == TIPO.DUO && this.cuota == CUOTA.MENSUAL) {
			this.precio = 14.99;
		} else if (this.tipo == TIPO.DUO && this.cuota == CUOTA.ANUAL) {
			this.precio = 169.99;
		} else if (this.tipo == TIPO.FAMILIAR && this.cuota == CUOTA.MENSUAL) {
			this.precio = 17.99;
		} else {
			this.precio = 199.99;
		}

		return this.precio;
	}

}
