package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase maneja las operaciones de acceso a datos relacionadas con el seguimiento de cuentas de usuario.
 */
public class CuentaSigueCuentaDAO {

	private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";
    
    /**
     * Constructor de la clase que establece la conexión a la base de datos.
     */
	public CuentaSigueCuentaDAO() {
		this.conexion = conectar();
	}
	
    /**
     * Establece la conexión a la base de datos.
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
        }

        return con;
    }
    
    /**
     * Crea una nueva entrada en la base de datos que representa que una cuenta sigue a otra.
     * @param follow La relación de seguimiento entre dos cuentas.
     */
    public void create(CuentaSigueCuenta follow) {
        if (follow != null) {
            String sql = "INSERT INTO CuentaSigueCuenta (idSeguido,idSeguidor,fecha) VALUES (?, ?, now())";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, follow.getIdSeguido());
                sentencia.setInt(2, follow.getIdSeguidor());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al insertar seguir en la base de datos");
            }
        } 
    }
    
    /**
     * Elimina la relación de seguimiento entre dos cuentas.
     * @param idSeguido El identificador de la cuenta seguida.
     * @param idSeguidor El identificador de la cuenta seguidora.
     */
    public void delete (int idSeguido,int idSeguidor) {
    	String sql = "DELETE FROM CuentaSigueCuenta WHERE idSeguido = ? AND idSeguidor = ?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setInt(1, idSeguido);
    		sentencia.setInt(2, idSeguidor);
    		sentencia.executeUpdate();
    	}
    	catch(SQLException ex) {
    		System.out.println("Error al dejar de seguir");
    	}
    }
    
    /**
     * Cuenta la cantidad de cuentas seguidas y seguidoras para una cuenta dada.
     * @param idCuenta El identificador de la cuenta para la cual se desea contar los seguidos y seguidores.
     */
    public void contarSeguidosSeguidores(int idCuenta) {
        String sql = "SELECT COUNT(*) AS seguidos FROM CuentaSigueCuenta WHERE idSeguidor = ?";
        String sql2 = "SELECT COUNT(*) AS seguidores FROM CuentaSigueCuenta WHERE idSeguido = ?";

        try {
            // Contar seguidos
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, idCuenta);
            ResultSet rs = sentencia.executeQuery();
            if (rs.next()) {
                int seguidos = rs.getInt("seguidos");
                System.out.println("Cantidad de seguidos: " + seguidos);
            }

            // Contar seguidores
            PreparedStatement sentencia2 = conexion.prepareStatement(sql2);
            sentencia2.setInt(1, idCuenta);
            ResultSet rs2 = sentencia2.executeQuery();
            if (rs2.next()) {
                int seguidores = rs2.getInt("seguidores");
                System.out.println("Cantidad de seguidores: " + seguidores);
            }

        } catch (SQLException ex) {
            System.out.println("Error al contar seguidos y seguidores");
        }
    }
}
