package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * La clase abstracta Publicaciones representa una publicación genérica.
 * Esta clase sirve como superclase para diferentes tipos de publicaciones.
 */
public abstract class Publicaciones {
	
	// Atributos
	private String isbn; // El ISBN de la publicación
	private String titulo; // El título de la publicación
	private LocalDate fecha_de_lanzamiento; // La fecha de lanzamiento de la publicación
	private boolean estado; // El estado de la publicación (activo o inactivo)
	private String fkAutorNombre; // El nombre del autor de la publicación
	private String fkAutorApellidos; // Los apellidos del autor de la publicación
	private String fkEditorial; // El nombre de la editorial de la publicación
	
	/**
	 * Constructor por defecto de la clase Publicaciones.
	 */
	public Publicaciones() {}

	/**
	 * Constructor con parámetros de la clase Publicaciones.
	 * 
	 * @param isbn el ISBN de la publicación
	 * @param titulo el título de la publicación
	 * @param fecha_de_lanzamiento la fecha de lanzamiento de la publicación en formato de cadena
	 * @param estado el estado de la publicación (activo o inactivo)
	 * @param fkAutorNombre el nombre del autor de la publicación
	 * @param fkAutorApellidos los apellidos del autor de la publicación
	 * @param fkEditorial el nombre de la editorial de la publicación
	 */
	public Publicaciones(String isbn, String titulo, String fecha_de_lanzamiento, boolean estado,
			String fkAutorNombre, String fkAutorApellidos, String fkEditorial) {
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		this.isbn = isbn;
		this.titulo = titulo;
		this.fecha_de_lanzamiento = LocalDate.parse(fecha_de_lanzamiento, f);
		this.estado = estado;
		this.fkAutorNombre = fkAutorNombre;
		this.fkAutorApellidos = fkAutorApellidos;
		this.fkEditorial = fkEditorial;
	}
	
	

	/**
	 * Constructor con parámetros de la clase Publicaciones.
	 * 
	 * @param isbn el ISBN de la publicación
	 * @param titulo el título de la publicación
	 * @param fecha_de_lanzamiento la fecha de lanzamiento de la publicación
	 * @param estado el estado de la publicación (activo o inactivo)
	 * @param fkAutorNombre el nombre del autor de la publicación
	 * @param fkAutorApellidos los apellidos del autor de la publicación
	 * @param fkEditorial el nombre de la editorial de la publicación
	 */
	public Publicaciones(String isbn, String titulo, LocalDate fecha_de_lanzamiento, boolean estado,
			String fkAutorNombre, String fkAutorApellidos, String fkEditorial) {
		super();
		this.isbn = isbn;
		this.titulo = titulo;
		this.fecha_de_lanzamiento = fecha_de_lanzamiento;
		this.estado = estado;
		this.fkAutorNombre = fkAutorNombre;
		this.fkAutorApellidos = fkAutorApellidos;
		this.fkEditorial = fkEditorial;
	}

	/**
	 * Constructor con parámetro ISBN de la clase Publicaciones.
	 * 
	 * @param isbn el ISBN de la publicación
	 */
	public Publicaciones(String isbn) {
		this.isbn= isbn;
	}

	// Métodos de acceso y modificación
	
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public LocalDate getFecha_de_lanzamiento() {
		return fecha_de_lanzamiento;
	}

	/**
	 * Establece la fecha de lanzamiento de la publicación.
	 * 
	 * @param fecha_de_lanzamiento la fecha de lanzamiento de la publicación en formato de cadena
	 */
	public void setFecha_de_lanzamiento(String fecha_de_lanzamiento) {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		this.fecha_de_lanzamiento = LocalDate.parse(fecha_de_lanzamiento, f);
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getFkAutorNombre() {
		return fkAutorNombre;
	}

	public void setFkAutorNombre(String fkAutorNombre) {
		this.fkAutorNombre = fkAutorNombre;
	}

	public String getFkAutorApellidos() {
		return fkAutorApellidos;
	}

	public void setFkAutorApellidos(String fkAutorApellidos) {
		this.fkAutorApellidos = fkAutorApellidos;
	}

	public String getFkEditorial() {
		return fkEditorial;
	}

	public void setFkEditorial(String fkEditorial) {
		this.fkEditorial = fkEditorial;
	}

	@Override
	public String toString() {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return "Publicaciones [isbn=" + isbn + ", titulo=" + titulo + ", fecha_de_lanzamiento=" + f.format(fecha_de_lanzamiento)
				+ ", estado=" + estado + ", fkAutorNombre=" + fkAutorNombre + ", fkAutorApellidos=" + fkAutorApellidos
				+ ", fkEditorial=" + fkEditorial + "]";
	}
}
