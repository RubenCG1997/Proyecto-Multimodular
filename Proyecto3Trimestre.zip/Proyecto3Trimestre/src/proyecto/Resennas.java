package proyecto;

/**
 * La clase Resennas representa una reseña de una publicación realizada por un usuario.
 * Contiene información sobre la opinión y la puntuación dada a la publicación.
 */
public class Resennas {
	
	// Atributos
	private int pkfkCuenta; // La clave primaria de la cuenta del usuario que realiza la reseña
	private String pkfkPublicacion; // La clave primaria de la publicación que recibe la reseña
	private String opinion; // La opinión del usuario sobre la publicación
	private int puntuacion; // La puntuación dada a la publicación por el usuario
	private boolean estado; // El estado de la reseña (activo o inactivo)
	
	/**
	 * Constructor por defecto de la clase Resennas.
	 */
	public Resennas() {}
	
	/**
	 * Constructor con parámetros de la clase Resennas.
	 * 
	 * @param pkfkCuenta la clave primaria de la cuenta del usuario que realiza la reseña
	 * @param pkfkPublicacion la clave primaria de la publicación que recibe la reseña
	 * @param opinion la opinión del usuario sobre la publicación
	 * @param puntuacion la puntuación dada a la publicación por el usuario
	 * @param estado el estado de la reseña (activo o inactivo)
	 */
	public Resennas(int pkfkCuenta, String pkfkPublicacion, String opinion, int puntuacion, boolean estado) {
		this.pkfkCuenta = pkfkCuenta;
		this.pkfkPublicacion = pkfkPublicacion;
		this.opinion = opinion;
		this.puntuacion = puntuacion;
		this.estado = estado;
	}

	// Métodos de acceso y modificación
	
	public int getPkfkCuenta() {
		return pkfkCuenta;
	}

	public void setPkfkCuenta(int pkfkCuenta) {
		this.pkfkCuenta = pkfkCuenta;
	}

	public String getPkfkPublicacion() {
		return pkfkPublicacion;
	}

	public void setPkfkPublicacion(String pkfkPublicacion) {
		this.pkfkPublicacion = pkfkPublicacion;
	}

	public String getOpinion() {
		return opinion;
	}

	public void setOpinion(String opinion) {
		this.opinion = opinion;
	}

	public int getPuntuacion() {
		return puntuacion;
	}

	public void setPuntuacion(int puntuacion) {
		this.puntuacion = puntuacion;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Resennas [pkfkCuenta=" + pkfkCuenta + ", pkfkPublicacion=" + pkfkPublicacion + ", opinion=" + opinion
				+ ", puntuacion=" + puntuacion + ", estado=" + estado + "]";
	}
}
