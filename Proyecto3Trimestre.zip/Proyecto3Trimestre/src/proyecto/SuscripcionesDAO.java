package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * La clase SuscripcionesDAO proporciona métodos para interactuar con la tabla Suscripciones en la base de datos.
 * Permite la creación, lectura, actualización y eliminación de suscripciones.
 */
public class SuscripcionesDAO {

    // Atributos
    private Connection conexion; // La conexión a la base de datos
    private final String USUARIO = "palProyecto"; // Usuario de la base de datos
    private final String PASSWORD = "123456789"; // Contraseña del usuario
    private final String MAQUINA = "localhost"; // Dirección de la máquina donde se encuentra la base de datos
    private final String BD = "proyectofinal"; // Nombre de la base de datos
    
    /**
     * Constructor de la clase SuscripcionesDAO que establece una conexión a la base de datos.
     */
    public SuscripcionesDAO() {
        this.conexion = conectar();
    }
    
    /**
     * Método privado para establecer una conexión a la base de datos.
     * 
     * @return la conexión establecida
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
         
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
           
        }

        return con;
    }

    // Métodos de interacción con la base de datos

    /**
     * Inserta una suscripción en la tabla Suscripciones de la base de datos.
     * 
     * @param suscripcion la suscripción a insertar
     */
    public void create(Suscripciones suscripcion) {
        if (suscripcion != null) {
            String sql = "INSERT INTO Suscripciones (tipo, cuota, precio) VALUES (?, ?, ?)";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, suscripcion.getTipo().name()); // Se obtiene el nombre del enum
                sentencia.setString(2, suscripcion.getCuota().name()); // Se obtiene el nombre del enum
                sentencia.setDouble(3, suscripcion.getPrecio());
                sentencia.executeUpdate();
               
            } catch (SQLException ex) {
                System.out.println("Error al insertar la suscripción en la base de datos");
                
            }
        } 
    }
   
    /**
     * Obtiene una suscripción de la tabla Suscripciones por su ID.
     * 
     * @param id el ID de la suscripción a obtener
     * @return la suscripción encontrada, o null si no se encuentra
     */
    public Suscripciones read(int id) {
        Suscripciones suscripciones = null;
        String sql = "SELECT * FROM Suscripciones WHERE idSuscripción=?";

        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            ResultSet rs = sentencia.executeQuery();
            if (rs.next()) {
                String tipoString = rs.getString("tipo");
                String cuotaString = rs.getString("cuota");

                // Convertimos los string en el enum
                Suscripciones.TIPO tipo = Suscripciones.TIPO.valueOf(tipoString);
                Suscripciones.CUOTA cuota = Suscripciones.CUOTA.valueOf(cuotaString);
                suscripciones = new Suscripciones(tipo, cuota);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar la suscripción");
        }
        return suscripciones;
    }
    
    /**
     * Actualiza una suscripción en la tabla Suscripciones de la base de datos.
     * 
     * @param suscripcion la suscripción a actualizar
     */
    public void update(Suscripciones suscripcion) {
        if(suscripcion != null) {
            String sql = "UPDATE Suscripciones SET tipo=?, cuota=?, precio=? WHERE idSuscripción=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, suscripcion.getTipo().name());
                sentencia.setString(2, suscripcion.getCuota().name());
                sentencia.setDouble(3, suscripcion.getPrecio());
                sentencia.executeUpdate();
            }
            catch(SQLException ex) {
                System.out.println("La suscripción que se quiere modificar no existe");
            }
        }
    }
    
    /**
     * Elimina una suscripción de la tabla Suscripciones de la base de datos.
     * 
     * @param id el ID de la suscripción a eliminar
     */
    public void delete (int id) {
        String sql = "DELETE FROM Suscripciones WHERE idSuscripción=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            sentencia.executeUpdate();
        }
        catch(SQLException ex) {
            System.out.println("Error al eliminar la suscripción");
        }
    }
    
    // Otros métodos adicionales

    /**
     * Obtiene el ID de la última suscripción insertada en la tabla Suscripciones.
     * 
     * @return el ID de la última suscripción
     */
    public int obtenerID() {
        int id = 0;
        String sql = "SELECT idSuscripción FROM Suscripciones ORDER BY idSuscripción DESC LIMIT 1";
        try {
              PreparedStatement sentencia = conexion.prepareStatement(sql);
              ResultSet rs = sentencia.executeQuery(); 
              while(rs.next()) {
                  id = rs.getInt("idSuscripción");
              }
        } catch(SQLException ex) {
            System.out.println("Error al buscar el ID");
        }
        return id;
    }
    
    /**
     * Obtiene información sobre todas las suscripciones, incluyendo el username, tipo, cuota y precio.
     * 
     * @return una lista de arrays de string con la información de las suscripciones
     */
    public ArrayList<String[]> infoTotal() {
        ArrayList<String[]> lista = new ArrayList<>();
        String sql= "SELECT Cuentas.username, Suscripciones.tipo, Suscripciones.cuota, Suscripciones.precio FROM Cuentas " +
                    "INNER JOIN Suscripciones ON Cuentas.fkSuscripciones = Suscripciones.idSuscripción";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            ResultSet rs =  sentencia.executeQuery();
            while (rs.next()) {
                String username = rs.getString("username");
                String tipo = rs.getString("tipo");
                String cuota = rs.getString("cuota");
                double precio = rs.getDouble("precio");
                String[] fila = {username, tipo, cuota, String.valueOf(precio)};
                lista.add(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener la información total de las suscripciones:");
        }

        return lista;
    }

    /**
     * Obtiene la cantidad de suscripciones agrupadas por tipo y cuota.
     * 
     * @return un mapa que asocia la combinación tipo-cuota con la cantidad de suscripciones
     */
    public Map<String, Integer> cantidadSuscripcionesPorTipoYCuota() {
        Map<String, Integer> cantidadPorTipoYCuota = new HashMap<>();
        String sql = "SELECT tipo, cuota, COUNT(*) AS cantidad FROM Suscripciones GROUP BY tipo, cuota";
        
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            ResultSet rs = sentencia.executeQuery();
            
            while (rs.next()) {
                String tipoString = rs.getString("tipo");
                String cuotaString = rs.getString("cuota");
                int cantidad = rs.getInt("cantidad");
                
                String clave = tipoString + "-" + cuotaString;
                cantidadPorTipoYCuota.put(clave, cantidad);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar las suscripciones");
        }
        
        return cantidadPorTipoYCuota;
    }
}
