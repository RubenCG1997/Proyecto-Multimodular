package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * La clase ResennasDAO proporciona métodos para interactuar con la tabla Resennas en la base de datos.
 * Permite la creación, lectura, actualización y eliminación de reseñas.
 */
public class ResennasDAO {
	
	// Atributos
	private Connection conexion; // La conexión a la base de datos
    private final String USUARIO = "palProyecto"; // Usuario de la base de datos
    private final String PASSWORD = "123456789"; // Contraseña del usuario
    private final String MAQUINA = "localhost"; // Dirección de la máquina donde se encuentra la base de datos
    private final String BD = "proyectofinal"; // Nombre de la base de datos
    
	/**
	 * Constructor de la clase ResennasDAO que establece una conexión a la base de datos.
	 */
	public ResennasDAO() {
		this.conexion = conectar();
	}
	
    /**
     * Método privado para establecer una conexión a la base de datos.
     * 
     * @return la conexión establecida
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
           
        }

        return con;
    }
    
    /**
     * Inserta una reseña en la tabla Resennas de la base de datos.
     * 
     * @param resenna la reseña a insertar
     */
    public void create(Resennas resenna) {
        if (resenna != null) {
            
            String sql = "INSERT INTO Resennas (pkfkCuenta,pkfkPublicacion,opinion,puntuacion,estado) VALUES (?, ?, ?, ?, ?)";
                    
            try {
                
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, resenna.getPkfkCuenta());
                sentencia.setString(2, resenna.getPkfkPublicacion());
                sentencia.setString(3, resenna.getOpinion());
                sentencia.setInt(4, resenna.getPuntuacion());
                sentencia.setBoolean(5, resenna.isEstado());
                sentencia.executeUpdate();

            } catch (SQLException ex) {
                System.out.println("Error al insertar la reseña en la base de datos");
               
            }
        } 
    }
    
    /**
     * Obtiene las reseñas asociadas a un número de cuenta específico.
     * 
     * @param pkfkCuenta el número de cuenta del usuario
     * @return una lista de reseñas asociadas al número de cuenta dado
     */
    public ArrayList<Resennas> read(int pkfkCuenta) {
    	ArrayList<Resennas> lista = new ArrayList<>();
    	Resennas resenna = null;
    	String sql = "SELECT * FROM Resennas WHERE pkfkCuenta=?";
    	
    	try {
    			PreparedStatement sentencia = conexion.prepareStatement(sql);
    			sentencia.setInt(1, pkfkCuenta);
    			ResultSet rs = sentencia.executeQuery();
    			while (rs.next()) {
    					
    					int numCuenta = rs.getInt("pkfkCuenta");
    					String isbn = rs.getString("pkfkPublicacion");
    					String opinion = rs.getString("opinion");
    					int puntuacion = rs.getInt("puntuacion");
    					boolean estado = rs.getBoolean("estado");

    					 resenna = new Resennas(numCuenta, isbn, opinion, puntuacion, estado);
    					 lista.add(resenna);
    				}
    		} catch (SQLException ex) {
    			System.out.println("Error al consultar las reseñas");
    		}
    		return lista;
    }
    
    /**
     * Modifica una reseña en la tabla Resennas de la base de datos.
     * 
     * @param resenna la reseña a modificar
     */
    public void update(Resennas resenna) {
    	if(resenna != null) {
    		String sql = "UPDATE Resennas SET opinion=?, puntuacion=?, estado=? WHERE pkfkCuenta=? AND pkfkPublicacion=?";
    		try {
        		PreparedStatement sentencia = conexion.prepareStatement(sql);
        		sentencia.setString(1, resenna.getOpinion());
        		sentencia.setInt(2, resenna.getPuntuacion());
        		sentencia.setBoolean(3, resenna.isEstado());
        		sentencia.setInt(4, resenna.getPkfkCuenta());
        		sentencia.setString(5, resenna.getPkfkPublicacion());
        		sentencia.executeUpdate();
        	}
    		catch(SQLException ex) {
    			System.out.println("La reseña que se quiere modificar no existe");
    		}
    	}
    	
    }
    
    /**
     * Elimina una reseña de la tabla Resennas de la base de datos.
     * 
     * @param cuenta el número de cuenta del usuario
     * @param isbn el ISBN de la publicación asociada a la reseña
     */
    public void delete (int cuenta, String isbn) {
    	String sql = "DELETE FROM Resennas WHERE pkfkCuenta=? AND pkfkPublicacion=?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setInt(1, cuenta);
    		sentencia.setString(2, isbn);
    		sentencia.executeUpdate();
    	}
    	catch(SQLException ex) {
    		System.out.println("Error al eliminar la reseña");
    	}
    }
}
