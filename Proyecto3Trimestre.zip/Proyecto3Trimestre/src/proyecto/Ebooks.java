package proyecto;

import java.time.LocalDate;

/**
 * La clase Ebooks representa publicaciones digitales en formato electrónico.
 * Hereda de la clase Publicaciones.
 */
public class Ebooks extends Publicaciones {

    private String formato;

    /**
     * Constructor de la clase Ebooks que inicializa todos los atributos.
     * @param isbn El ISBN del ebook.
     * @param titulo El título del ebook.
     * @param fecha_de_lanzamiento La fecha de lanzamiento del ebook.
     * @param estado El estado del ebook.
     * @param fkAutorNombre El nombre del autor del ebook.
     * @param fkAutorApellidos Los apellidos del autor del ebook.
     * @param fkEditorial El nombre de la editorial del ebook.
     * @param formato El formato del ebook.
     */
    public Ebooks(String isbn, String titulo, String fecha_de_lanzamiento, boolean estado, String fkAutorNombre,
            String fkAutorApellidos, String fkEditorial, String formato) {
        super(isbn, titulo, fecha_de_lanzamiento, estado, fkAutorNombre, fkAutorApellidos, fkEditorial);
        this.formato = formato;
    }

    /**
     * Constructor alternativo de la clase Ebooks que permite usar LocalDate para la fecha de lanzamiento.
     * @param isbn El ISBN del ebook.
     * @param titulo El título del ebook.
     * @param fecha_de_lanzamiento La fecha de lanzamiento del ebook como LocalDate.
     * @param estado El estado del ebook.
     * @param fkAutorNombre El nombre del autor del ebook.
     * @param fkAutorApellidos Los apellidos del autor del ebook.
     * @param fkEditorial El nombre de la editorial del ebook.
     * @param formato El formato del ebook.
     */
    public Ebooks(String isbn, String titulo, LocalDate fecha_de_lanzamiento, boolean estado, String fkAutorNombre,
            String fkAutorApellidos, String fkEditorial, String formato) {
        super(isbn, titulo, fecha_de_lanzamiento, estado, fkAutorNombre, fkAutorApellidos, fkEditorial);
        this.formato = formato;
    }

    /**
     * Método getter para obtener el formato del ebook.
     * @return El formato del ebook.
     */
    public String getFormato() {
        return formato;
    }

    /**
     * Método setter para establecer el formato del ebook.
     * @param formato El formato del ebook.
     */
    public void setFormato(String formato) {
        this.formato = formato;
    }

    /**
     * Método toString que devuelve una representación en forma de cadena del objeto Ebook.
     * @return Una cadena que representa el Ebook, incluyendo su formato.
     */
    @Override
    public String toString() {
        return super.toString() + " Ebooks [formato=" + formato + "]";
    }
}
