package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Esta clase representa una cuenta de usuario en el sistema.
 */
public class Cuentas {

	private String username;
	private LocalDate fecha_de_creacion;
	private String fkUsuario;
	private int fkSuscripcion;
	
	/**
	 * Constructor por defecto de la clase.
	 */
	public Cuentas() {}

	/**
	 * Constructor que inicializa una cuenta con la fecha actual.
	 * @param username El nombre de usuario.
	 * @param fkUsuario El identificador del usuario.
	 * @param fkSuscripcion El identificador de la suscripción.
	 */
	public Cuentas(String username, String fkUsuario, int fkSuscripcion) {
		
		this.username = username;
		this.fecha_de_creacion=LocalDate.now();
		this.fkUsuario = fkUsuario;
		this.fkSuscripcion = fkSuscripcion;
	}
	
	/**
	 * Constructor que inicializa una cuenta con una fecha proporcionada.
	 * @param username El nombre de usuario.
	 * @param fecha_de_creacion La fecha de creación de la cuenta en formato de cadena (YYYY-MM-DD).
	 * @param fkUsuario El identificador del usuario.
	 * @param fkSuscripcion El identificador de la suscripción.
	 */
	public Cuentas(String username, String fecha_de_creacion, String fkUsuario, int fkSuscripcion) {
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		this.username = username;
		this.fecha_de_creacion = LocalDate.parse(fecha_de_creacion,f);
		this.fkUsuario = fkUsuario;
		this.fkSuscripcion = fkSuscripcion;
	}

	/**
	 * Obtiene el nombre de usuario.
	 * @return El nombre de usuario.
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Establece el nombre de usuario.
	 * @param username El nombre de usuario a establecer.
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Obtiene la fecha de creación de la cuenta.
	 * @return La fecha de creación de la cuenta.
	 */
	public LocalDate getFecha_de_creacion() {
		return fecha_de_creacion;
	}

	/**
	 * Establece la fecha de creación de la cuenta.
	 * @param fecha_de_creacion La fecha de creación de la cuenta en formato de cadena (YYYY-MM-DD).
	 */
	public void setFecha_de_creacion(String fecha_de_creacion) {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		this.fecha_de_creacion = LocalDate.parse(fecha_de_creacion,f);
	}
	

	/**
	 * Obtiene el identificador del usuario.
	 * @return El identificador del usuario.
	 */
	public String getFkUsuario() {
		return fkUsuario;
	}

	/**
	 * Establece el identificador del usuario.
	 * @param fkUsuario El identificador del usuario a establecer.
	 */
	public void setFkUsuario(String fkUsuario) {
		this.fkUsuario = fkUsuario;
	}

	/**
	 * Obtiene el identificador de la suscripción.
	 * @return El identificador de la suscripción.
	 */
	public int getFkSuscripcion() {
		return fkSuscripcion;
	}

	/**
	 * Establece el identificador de la suscripción.
	 * @param fkSuscripcion El identificador de la suscripción a establecer.
	 */
	public void setFkSuscripcion(int fkSuscripcion) {
		this.fkSuscripcion = fkSuscripcion;
	}

	/**
	 * Retorna una representación en cadena de la clase.
	 * @return Una cadena que representa la cuenta.
	 */
	@Override
	public String toString() {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return "Cuentas [username=" + username + ", fecha_de_creacion=" + f.format(fecha_de_creacion) + ","
				+ ", fkUsuario=" + fkUsuario + ", fkSuscripcion=" + fkSuscripcion + "]";
	}

}
