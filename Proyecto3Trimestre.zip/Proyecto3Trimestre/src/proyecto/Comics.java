package proyecto;

import java.time.LocalDate;

/**
 * La clase Comics representa cómics que extienden la clase Publicaciones.
 */
public class Comics extends Publicaciones {

    private boolean color;

    /**
     * Constructor por defecto de la clase Comics.
     */
    public Comics() {
        super();
    }

    /**
     * Constructor de la clase Comics que inicializa los atributos de un cómic.
     * 
     * @param isbn              El ISBN del cómic.
     * @param titulo            El título del cómic.
     * @param fecha_de_lanzamiento La fecha de lanzamiento del cómic en formato de cadena.
     * @param estado            El estado del cómic.
     * @param fkAutorNombre     El nombre del autor del cómic.
     * @param fkAutorApellidos  Los apellidos del autor del cómic.
     * @param fkEditorial       La editorial del cómic.
     * @param color             Indica si el cómic está en color o en blanco y negro.
     */
    public Comics(String isbn, String titulo, String fecha_de_lanzamiento, boolean estado, String fkAutorNombre,
                  String fkAutorApellidos, String fkEditorial, boolean color) {
        super(isbn, titulo, fecha_de_lanzamiento, estado, fkAutorNombre, fkAutorApellidos, fkEditorial);
        this.color = color;
    }

    /**
     * Constructor de la clase Comics que inicializa los atributos de un cómic.
     * 
     * @param isbn              El ISBN del cómic.
     * @param titulo            El título del cómic.
     * @param fecha_de_lanzamiento La fecha de lanzamiento del cómic.
     * @param estado            El estado del cómic.
     * @param fkAutorNombre     El nombre del autor del cómic.
     * @param fkAutorApellidos  Los apellidos del autor del cómic.
     * @param fkEditorial       La editorial del cómic.
     * @param color             Indica si el cómic está en color o en blanco y negro.
     */
    public Comics(String isbn, String titulo, LocalDate fecha_de_lanzamiento, boolean estado, String fkAutorNombre,
                  String fkAutorApellidos, String fkEditorial, boolean color) {
        super(isbn, titulo, fecha_de_lanzamiento, estado, fkAutorNombre, fkAutorApellidos, fkEditorial);
        this.color = color;
    }

    /**
     * Obtiene el indicador de color del cómic.
     * 
     * @return true si el cómic está en color, false si está en blanco y negro.
     */
    public boolean isColor() {
        return color;
    }

    /**
     * Establece el indicador de color del cómic.
     * 
     * @param color true si el cómic está en color, false si está en blanco y negro.
     */
    public void setColor(boolean color) {
        this.color = color;
    }

    /**
     * Retorna una representación en cadena del cómic.
     * 
     * @return Una cadena que representa el cómic.
     */
    @Override
    public String toString() {
        return super.toString() + " Comic [color=" + color + "]";
    }
}
