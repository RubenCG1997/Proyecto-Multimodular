package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Esta clase proporciona métodos para interactuar con la base de datos
 * para la gestión de editoriales.
 */
public class EditorialesDAO {
    
    private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";
    
    /**
     * Constructor de la clase. Inicializa la conexión a la base de datos.
     */
    public EditorialesDAO() {
        this.conexion = conectar();
    }
    
    /**
     * Establece una conexión a la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
        }

        return con;
    }
    
    /**
     * Inserta una nueva editorial en la base de datos.
     * 
     * @param editorial La editorial a añadir.
     */
    public void create(Editoriales editorial) {
        if (editorial != null) {
            String sql = "INSERT INTO Editoriales (cif, nombre, direccion, telefono, cp, estado )"
                    + " VALUES(?, ?, ?, ?, ?, ?)";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, editorial.getCif());
                sentencia.setString(2, editorial.getNombre());
                sentencia.setString(3, editorial.getDireccion());
                sentencia.setString(4, editorial.getTelefono());
                sentencia.setString(5, editorial.getCp());
                sentencia.setBoolean(6, editorial.isEstado());
                sentencia.executeUpdate();
                System.out.println("Editorial añadida");
            } catch (SQLException ex) {
                System.out.println("La editorial cuyo cif, nombre, dirección o teléfono ya existe, no se puede añadir a la base de datos");
            }
        } 
    }
    
    /**
     * Recupera información de una editorial de la base de datos basándose en su CIF.
     * 
     * @param cif El CIF de la editorial a buscar.
     * @return Una lista de editoriales encontradas.
     */
    public ArrayList<Editoriales> read(String cif) {
        ArrayList<Editoriales> lista = new ArrayList<>();
        Editoriales editorial = null;
        String sql = "SELECT * FROM Editoriales WHERE cif Like ?";
        
        try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, cif+"%");
                ResultSet rs = sentencia.executeQuery();
                while (rs.next()) {
                        String cifEdi = rs.getString("cif");
                        String nombre = rs.getString("nombre");
                        String direccion = rs.getString("direccion");
                        String telefono = rs.getString("telefono");
                        String cp = rs.getString("cp");
                        boolean estado = rs.getBoolean("estado");
                    
                        editorial = new Editoriales(cifEdi, nombre, direccion, telefono, cp, estado);
                        lista.add(editorial);
                    }
            } catch (SQLException ex) {
                System.out.println("Error al buscar la/s editorial/es");
            }
            return lista;
        }
    
    /**
     * Modifica la información de una editorial en la base de datos.
     * 
     * @param editorial La editorial con la información actualizada.
     */
    public void update(Editoriales editorial) {
        if(editorial != null) {
            String sql = "UPDATE Editoriales SET nombre=?, direccion=?, telefono=?, cp=?, estado=?"
                    + " WHERE cif=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, editorial.getNombre());
                sentencia.setString(2, editorial.getDireccion());
                sentencia.setString(3, editorial.getTelefono());
                sentencia.setString(4, editorial.getCp());
                sentencia.setBoolean(5, editorial.isEstado());
                sentencia.setString(6, editorial.getCif());
                sentencia.executeUpdate();
            }
            catch(SQLException ex) {
                System.out.println("No se pudo modificar la editorial");
            }
        }
        
    }
    
    /**
     * Elimina una editorial de la base de datos.
     * 
     * @param cif El CIF de la editorial a eliminar.
     */
    public void delete (String cif) {
        String sql = "DELETE FROM Editoriales WHERE cif =?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setString(1, cif);
            sentencia.executeUpdate();
        }
        catch(SQLException ex) {
            System.out.println("Error al eliminar la editorial");
        }
    }

}
