package proyecto;

/**
 * Esta clase representa la entidad MeGusta, que indica que a un usuario le gusta una lista.
 */
public class MeGusta {
    
    private int pkfkCuenta;
    private String pkfkNombreLista;
    private int pkfkCuentaLista;
    
    /**
     * Constructor por defecto de la clase.
     */
    public MeGusta() {}

    /**
     * Constructor con parámetros de la clase.
     * 
     * @param pkfkCuenta El identificador de la cuenta a la que le gusta la lista.
     * @param pkfkNombreLista El nombre de la lista que le gusta al usuario.
     * @param pkfkCuentaLista El identificador de la cuenta asociada a la lista que le gusta al usuario.
     */
    public MeGusta(int pkfkCuenta, String pkfkNombreLista, int pkfkCuentaLista) {
        this.pkfkCuenta = pkfkCuenta;
        this.pkfkNombreLista = pkfkNombreLista;
        this.pkfkCuentaLista = pkfkCuentaLista;
    }

    /**
     * Método getter para obtener el identificador de la cuenta a la que le gusta la lista.
     * 
     * @return El identificador de la cuenta.
     */
    public int getPkfkCuenta() {
        return pkfkCuenta;
    }

    /**
     * Método setter para establecer el identificador de la cuenta a la que le gusta la lista.
     * 
     * @param pkfkCuenta El nuevo identificador de la cuenta.
     */
    public void setPkfkCuenta(int pkfkCuenta) {
        this.pkfkCuenta = pkfkCuenta;
    }

    /**
     * Método getter para obtener el nombre de la lista que le gusta al usuario.
     * 
     * @return El nombre de la lista.
     */
    public String getPkfkNombreLista() {
        return pkfkNombreLista;
    }

    /**
     * Método setter para establecer el nombre de la lista que le gusta al usuario.
     * 
     * @param pkfkNombreLista El nuevo nombre de la lista.
     */
    public void setPkfkNombreLista(String pkfkNombreLista) {
        this.pkfkNombreLista = pkfkNombreLista;
    }

    /**
     * Método getter para obtener el identificador de la cuenta asociada a la lista que le gusta al usuario.
     * 
     * @return El identificador de la cuenta asociada a la lista.
     */
    public int getPkfkCuentaLista() {
        return pkfkCuentaLista;
    }

    /**
     * Método setter para establecer el identificador de la cuenta asociada a la lista que le gusta al usuario.
     * 
     * @param pkfkCuentaLista El nuevo identificador de la cuenta asociada a la lista.
     */
    public void setPkfkCuentaLista(int pkfkCuentaLista) {
        this.pkfkCuentaLista = pkfkCuentaLista;
    }

    /**
     * Método que devuelve una representación en forma de cadena del objeto MeGusta.
     * 
     * @return Una cadena que representa el objeto MeGusta.
     */
    @Override
    public String toString() {
        return "MeGusta [pkfkCuenta=" + pkfkCuenta + ", pkfkNombreLista=" + pkfkNombreLista + ", pkfkCuentaLista="
                + pkfkCuentaLista + "]";
    }
}
