package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase proporciona métodos para interactuar con la base de datos
 * para la gestión de la relación entre listas y publicaciones.
 */
public class ListaContienePublicacionesDAO {

    private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";

    /**
     * Constructor de la clase. Inicializa la conexión a la base de datos.
     */
    public ListaContienePublicacionesDAO() {
        this.conexion = conectar();
    }

    /**
     * Establece una conexión a la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
        }

        return con;
    }

    /**
     * Inserta un libro en una lista en la base de datos.
     * 
     * @param addLibro La relación entre la lista y el libro a añadir.
     */
    public void create(ListaContienePublicaciones addLibro) {
        if (addLibro != null) {
            String sql = "INSERT INTO ListaContienePublicaciones (pkfkPublicacion,pkfkNombreLista,pkfkCuentaLista) VALUES (?, ?, ?)";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, addLibro.getPkfkPublicacion());
                sentencia.setString(2, addLibro.getPkfkNombreLista());
                sentencia.setInt(3, addLibro.getPkfkCuentaLista());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al insertar el libro en la lista ");
            }
        } 
    }

    /**
     * Recupera información de una lista y sus libros asociados de la base de datos.
     * 
     * @param pkfkPublicacion El identificador de la publicación.
     * @param pkfkNombreLista El nombre de la lista.
     * @param pkfkCuenta El identificador de la cuenta asociada a la lista.
     * @return La relación entre la lista y la publicación recuperada.
     */
    public ListaContienePublicaciones read(String pkfkPublicacion, String pkfkNombreLista, int pkfkCuenta) {
        ListaContienePublicaciones lista = null;
        String sql = "SELECT * FROM ListaContienePublicaciones WHERE pkfkPublicacion=? AND pkfkNombreLista=? AND pkfkCuentaLista=?";
        
        try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, pkfkPublicacion);
                sentencia.setString(2, pkfkNombreLista);
                sentencia.setInt(3, pkfkCuenta);
                
                ResultSet rs = sentencia.executeQuery();
                if (rs.next()) {
                    String isbn = rs.getString("pkfkPublicacion");
                    String nombreLista = rs.getString("pkfkNombreLista");
                    int numCuenta = rs.getInt("pkfkCuentaLista");
                    lista = new ListaContienePublicaciones(isbn, nombreLista, numCuenta);
                }
            } catch (SQLException ex) {
                System.out.println("Error al consultar la lista");
            }
            return lista;
    }

    /**
     * Elimina un libro de una lista en la base de datos.
     * 
     * @param isbn El identificador del libro a eliminar.
     * @param nombre El nombre de la lista.
     * @param listaCuenta El identificador de la cuenta asociada a la lista.
     */
    public void delete(String isbn, String nombre, int listaCuenta) {
        String sql = "DELETE FROM ListaContienePublicaciones WHERE pkfkPublicacion=? AND pkfkNombreLista=? AND pkfkCuentaLista=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setString(1, isbn);
            sentencia.setString(2, nombre);
            sentencia.setInt(3, listaCuenta);
            sentencia.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el libro de la lista");
        }
    }

}
