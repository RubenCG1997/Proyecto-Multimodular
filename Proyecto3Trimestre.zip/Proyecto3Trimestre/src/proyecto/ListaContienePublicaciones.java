package proyecto;

/**
 * Esta clase representa una relación entre una lista y una publicación.
 * Contiene información sobre la publicación asociada a una lista específica.
 */
public class ListaContienePublicaciones {

    private String pkfkPublicacion;
    private String pkfkNombreLista;
    private int pkfkCuentaLista;
    
    /**
     * Constructor por defecto de la clase.
     */
    public ListaContienePublicaciones() {}

    /**
     * Constructor con parámetros de la clase.
     * 
     * @param pkfkPublicacion El identificador de la publicación.
     * @param pkfkNombreLista El nombre de la lista.
     * @param pkfkCuentaLista El identificador de la cuenta asociada a la lista.
     */
    public ListaContienePublicaciones(String pkfkPublicacion, String pkfkNombreLista, int pkfkCuentaLista) {
        this.pkfkPublicacion = pkfkPublicacion;
        this.pkfkNombreLista = pkfkNombreLista;
        this.pkfkCuentaLista = pkfkCuentaLista;
    }

    /**
     * Método getter para obtener el identificador de la publicación.
     * 
     * @return El identificador de la publicación.
     */
    public String getPkfkPublicacion() {
        return pkfkPublicacion;
    }

    /**
     * Método setter para establecer el identificador de la publicación.
     * 
     * @param pkfkPublicacion El nuevo identificador de la publicación.
     */
    public void setPkfkPublicacion(String pkfkPublicacion) {
        this.pkfkPublicacion = pkfkPublicacion;
    }

    /**
     * Método getter para obtener el nombre de la lista.
     * 
     * @return El nombre de la lista.
     */
    public String getPkfkNombreLista() {
        return pkfkNombreLista;
    }

    /**
     * Método setter para establecer el nombre de la lista.
     * 
     * @param pkfkNombreLista El nuevo nombre de la lista.
     */
    public void setPkfkNombreLista(String pkfkNombreLista) {
        this.pkfkNombreLista = pkfkNombreLista;
    }

    /**
     * Método getter para obtener el identificador de la cuenta asociada a la lista.
     * 
     * @return El identificador de la cuenta asociada a la lista.
     */
    public int getPkfkCuentaLista() {
        return pkfkCuentaLista;
    }

    /**
     * Método setter para establecer el identificador de la cuenta asociada a la lista.
     * 
     * @param pkfkCuentaLista El nuevo identificador de la cuenta asociada a la lista.
     */
    public void setPkfkCuentaLista(int pkfkCuentaLista) {
        this.pkfkCuentaLista = pkfkCuentaLista;
    }

    /**
     * Método que devuelve una representación en forma de cadena de la relación
     * entre la lista y la publicación.
     * 
     * @return Una cadena que representa la relación.
     */
    @Override
    public String toString() {
        return "ListaContienePublicaciones [pkfkPublicacion=" + pkfkPublicacion + ", pkfkNombreLista=" + pkfkNombreLista
                + ", pkfkCuentaLista=" + pkfkCuentaLista + "]";
    }
}
