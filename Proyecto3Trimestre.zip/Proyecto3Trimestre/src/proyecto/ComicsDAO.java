package proyecto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Esta clase proporciona métodos para acceder y manipular la base de datos relacionada con los cómics.
 */
public class ComicsDAO {
	
	private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";
    
    /**
     * Constructor que inicializa la conexión con la base de datos.
     */
	public ComicsDAO() {
		this.conexion = conectar();
	}
	
    /**
     * Establece la conexión con la base de datos.
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
        }

        return con;
    }
    
    /**
     * Inserta un nuevo cómic en la base de datos.
     * @param comic El cómic a insertar.
     */
    public void create(Comics comic) {
        if (comic != null) {
            String sql = "INSERT INTO Publicaciones (isbn, titulo, fecha_de_lanzamiento, estado, fkAutorNombre, fkAutorApellidos, fkEditorial) VALUES (?, ?, ?, ?, ?, ?, ?)";
            String sql2 = "INSERT INTO Comics (pkfkPublicacion, color) VALUES (?, ?)";
                    
            try {
                // Insertar en la tabla Publicaciones
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, comic.getIsbn());
                sentencia.setString(2, comic.getTitulo());
                sentencia.setDate(3, Date.valueOf(comic.getFecha_de_lanzamiento()));
                sentencia.setBoolean(4, comic.isEstado());
                sentencia.setString(5, comic.getFkAutorNombre());
                sentencia.setString(6, comic.getFkAutorApellidos());
                sentencia.setString(7, comic.getFkEditorial());
                sentencia.executeUpdate();

                // Insertar en la tabla Comics
                PreparedStatement sentencia2 = conexion.prepareStatement(sql2);
                sentencia2.setString(1, comic.getIsbn());
                sentencia2.setBoolean(2, comic.isColor());
                sentencia2.executeUpdate();
                
            } catch (SQLException ex) {
                System.out.println("Error al insertar el comic en la base de datos: ");
            }
        } 
    }
    
    /**
     * Lee la información de los cómics basada en su identificador de publicación.
     * @param pkfkPublicacion El identificador de publicación del cómic.
     * @param lista La lista en la que se agregarán los cómics leídos.
     * @return La lista actualizada de cómics.
     */
    public ArrayList<Publicaciones> read(String pkfkPublicacion,ArrayList<Publicaciones>lista) {

    	Comics comic = null;
    	String sql = "SELECT Publicaciones.*, Comics.color FROM Publicaciones INNER JOIN Comics ON Publicaciones.isbn = Comics.pkfkPublicacion WHERE Comics.pkfkPublicacion Like ?";
    	
    	try {
    			PreparedStatement sentencia = conexion.prepareStatement(sql);
    			sentencia.setString(1, pkfkPublicacion+"%");
    			ResultSet rs = sentencia.executeQuery();
    			while (rs.next()) {
    					String isbn = rs.getString("isbn");
    					String titulo = rs.getString("titulo");
    					String fecha_de_lanzamiento = rs.getString("fecha_de_lanzamiento");
    					boolean estado = rs.getBoolean("estado");
    					String fkAutorNombre = rs.getString("fkAutorNombre");
    					String fkAutorApellidos = rs.getString("fkAutorApellidos");
    					String fkEditorial = rs.getString("fkEditorial");
    					boolean color = rs.getBoolean("color");
    					comic = new Comics(isbn,titulo,fecha_de_lanzamiento,estado,fkAutorNombre,fkAutorApellidos,fkEditorial,color);
    					lista.add(comic);
    				}
    		} catch (SQLException ex) {
    			System.out.println("Error al consultar el comic");
    		}
    		return lista;
    }
    
    /**
     * Busca publicaciones de cómics por título.
     * @param titulo El título del cómic a buscar.
     * @param lista La lista en la que se agregarán los cómics encontrados.
     * @return La lista actualizada de cómics.
     */
    public ArrayList<Publicaciones> readPorTitulo(String titulo,ArrayList<Publicaciones>lista) {
    	
    	Comics comic = null;
    	String sql =  "SELECT Publicaciones.*, Comics.color FROM Publicaciones INNER JOIN Comics ON Publicaciones.isbn = Comics.pkfkPublicacion WHERE Publicaciones.titulo LIKE ?";
    	
    	try {
    			PreparedStatement sentencia = conexion.prepareStatement(sql);
    			sentencia.setString(1, titulo+"%");
    			ResultSet rs = sentencia.executeQuery();
    			while (rs.next()) {
    					String isbn = rs.getString("isbn");
    					String tituloN = rs.getString("titulo");
    					String fecha_de_lanzamiento = rs.getString("fecha_de_lanzamiento");
    					boolean estado = rs.getBoolean("estado");
    					String fkAutorNombre = rs.getString("fkAutorNombre");
    					String fkAutorApellidos = rs.getString("fkAutorApellidos");
    					String fkEditorial = rs.getString("fkEditorial");
    					boolean color = rs.getBoolean("color");
    					comic = new Comics(isbn,tituloN,fecha_de_lanzamiento,estado,fkAutorNombre,fkAutorApellidos,fkEditorial,color);
    					lista.add(comic);
    				}
    		} catch (SQLException ex) {
    			System.out.println("Error al consultar el comic");
    		}
    		return lista;
    }
    
    /**
     * Actualiza la información de un cómic en la base de datos.
     * @param comic El cómic con la información actualizada.
     */
    public void update(Comics comic) {
    	if(comic != null) {
    	    String sql = "UPDATE Publicaciones INNER JOIN Comics ON Publicaciones.isbn = Comics.pkfkPublicacion"
    	            + " SET Publicaciones.titulo=?, Publicaciones.estado=?, Publicaciones.fkAutorNombre=?, Publicaciones.fkAutorApellidos=?,"
    	            + " Publicaciones.fkEditorial=?, Comics.color=?"
    	            + " WHERE Comics.pkfkPublicacion=?";
    		try {
        		PreparedStatement sentencia = conexion.prepareStatement(sql);
        		sentencia.setString(1, comic.getTitulo());
        		sentencia.setBoolean(2, comic.isEstado());
        		sentencia.setString(3, comic.getFkAutorNombre());
        		sentencia.setString(4, comic.getFkAutorApellidos());
        		sentencia.setString(5, comic.getFkEditorial());
        		sentencia.setBoolean(6, comic.isColor());
        		sentencia.setString(7, comic.getIsbn());
        		sentencia.executeUpdate();
        	
        	} catch(SQLException ex) {
        		System.out.println("El comic no se puede modificar");
        	}
    	}
    }
    
    /**
     * Elimina un cómic de la base de datos.
     * @param isbn El ISBN del cómic a eliminar.
     */
    public void delete(String isbn) {
    	String sql = "DELETE FROM Publicaciones WHERE isbn =?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setString(1,isbn);
    		sentencia.executeUpdate();
    	} catch(SQLException ex) {
    		System.out.println("Error al eliminar el comic");
    	}
    }
}
