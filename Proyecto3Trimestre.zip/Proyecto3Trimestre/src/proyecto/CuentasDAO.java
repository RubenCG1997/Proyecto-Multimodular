package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase gestiona las operaciones de acceso a datos para las cuentas de usuario en la base de datos.
 */
public class CuentasDAO {
	
	private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";
    
    /**
     * Constructor de la clase que establece la conexión a la base de datos.
     */
	public CuentasDAO() {
		this.conexion = conectar();
	}
	
    /**
     * Establece la conexión a la base de datos.
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
           
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
           
        }

        return con;
    }
    
    /**
     * Inserta una cuenta en la tabla cuentas.
     * @param cuenta La cuenta a insertar en la base de datos.
     */
    public void create(Cuentas cuenta) {
        if (cuenta != null) {
            String sql = "INSERT INTO Cuentas ( username, fecha_de_creacion,fkUsuario, fkSuscripciones )"
            		+ " VALUES(?, now(), ?, ?)";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, cuenta.getUsername());
                sentencia.setString(2,cuenta.getFkUsuario());
                sentencia.setInt(3, cuenta.getFkSuscripcion());
                sentencia.executeUpdate();
               
            } catch (SQLException ex) {
                System.out.println("Error al insertar la cuenta en la base de datos");
                
            }
        } 
    }
    
    /**
     * Obtiene la información de una cuenta específica.
     * @param id El identificador de la cuenta a buscar.
     * @return La cuenta encontrada, o null si no se encontró ninguna cuenta con el identificador especificado.
     */
    public Cuentas read(String id) {

    	Cuentas cuentas = null;
    	String sql = "SELECT * FROM Cuentas WHERE fkUsuario=?";
    	
    	try {
    			PreparedStatement sentencia = conexion.prepareStatement(sql);
    			sentencia.setString(1, id);
    			ResultSet rs = sentencia.executeQuery();
    			if (rs.next()) {
    				
    					String username = rs.getString("username");
    					String fkUsuario = rs.getString("fkUsuario");
    					int fkSuscripciones = rs.getInt("fkSuscripciones");
    				
    					cuentas = new Cuentas(username,fkUsuario,fkSuscripciones);
    				}
    		} catch (SQLException ex) {
    			System.out.println("Error al consultar la cuenta");
    		}
    		return cuentas;
    	}
    
    /**
     * Actualiza la información de una cuenta en la base de datos.
     * @param cuenta La cuenta con la información actualizada.
     */
    public void update(Cuentas cuenta) {
    	if(cuenta != null) {
    		String sql = "UPDATE Cuentas SET username=?,"
    				+ " WHERE fkUsuario=?";
    		try {
        		PreparedStatement sentencia = conexion.prepareStatement(sql);
        		sentencia.setString(1, cuenta.getUsername());
        		sentencia.setString(2, cuenta.getFkUsuario());
        		sentencia.executeUpdate();
        	}
    		catch(SQLException ex) {
    			System.out.println("La cuenta que se quiere modificar no existe");
    		}
    	}
    	
    }
    
    /**
     * Elimina una cuenta de la base de datos.
     * @param id El identificador de la cuenta a eliminar.
     */
    public void delete (int id) {
    	String sql = "DELETE FROM Cuentas WHERE idCuenta =?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setInt(1, id);
    		sentencia.executeUpdate();
    	}
    	catch(SQLException ex) {
    		System.out.println("Error al eliminar la cuenta");
    	}
    }
    
    /**
     * Comprueba si un username ya existe en la base de datos.
     * @param username El username a comprobar.
     * @return true si el username ya existe, false si no.
     */
    public boolean usernameExiste(String username) {
    	
    	boolean existe = false;
    	String sql = "SELECT username FROM Cuentas WHERE username=?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setString(1,username);
    		ResultSet rs = sentencia.executeQuery(); 
    		if(rs.next()) {
    			existe =true;
    		}
    		if(existe) {
    			System.out.println("El username existe,pon otro");
    		}
    	}catch(SQLException ex){
    		System.out.println("Error al buscar el username");
    	}
    	return existe;
    	 	
    }
    
    /**
     * Obtiene el identificador de una cuenta a partir del username.
     * @param username El username de la cuenta.
     * @return El identificador de la cuenta.
     */
    public int obtenerId(String username) {
    	int id = 0;
    	String sql = "SELECT idCuenta FROM Cuentas WHERE username=?";
    	try {
    		PreparedStatement sentencia = conexion.prepareStatement(sql);
    		sentencia.setString(1,username);
    		ResultSet rs = sentencia.executeQuery(); 
    		if(rs.next()) {
    			id =rs.getInt("idCuenta");
    		}
    	}catch(SQLException ex){
    		System.out.println("Error al buscar el username");
    	}
    	return id;
    }
}
