package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * La clase Usuarios representa a los usuarios del sistema.
 * Cada usuario tiene un DNI, nombre, apellidos, correo electrónico, contraseña, fecha de nacimiento, rol y estado.
 */
public class Usuarios {
	
	// Atributos
	private String dni; // El DNI del usuario
	private String nombre; // El nombre del usuario
	private String apellidos; // Los apellidos del usuario
	private String email; // El correo electrónico del usuario
	private String contrasenna; // La contraseña del usuario
	private LocalDate fecha_de_nacimiento; // La fecha de nacimiento del usuario
	private boolean rol; // El rol del usuario (true si es administrador, false si es usuario normal)
	private boolean estado; // El estado del usuario (true si está activo, false si está inactivo)
	
	// Constructores
	
	/**
	 * Constructor por defecto de la clase Usuarios.
	 */
	public Usuarios() {
		
	}
	
	/**
	 * Constructor de la clase Usuarios que inicializa todos los atributos.
	 * 
	 * @param dni el DNI del usuario
	 * @param nombre el nombre del usuario
	 * @param apellidos los apellidos del usuario
	 * @param email el correo electrónico del usuario
	 * @param contrasenna la contraseña del usuario
	 * @param fecha_de_nacimiento la fecha de nacimiento del usuario en formato String ("yyyy-MM-dd")
	 * @param rol el rol del usuario (true si es administrador, false si es usuario normal)
	 * @param estado el estado del usuario (true si está activo, false si está inactivo)
	 */
	public Usuarios(String dni, String nombre, String apellidos, String email, String contrasenna,
			String fecha_de_nacimiento, boolean rol, boolean estado) {
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.email = email;
		this.contrasenna = contrasenna;
		this.fecha_de_nacimiento = LocalDate.parse(fecha_de_nacimiento, f);
		this.rol = rol;
		this.estado = estado;
	}
	
	// Métodos Getters y Setters
	
	/**
	 * Devuelve el DNI del usuario.
	 * 
	 * @return el DNI del usuario
	 */
	public String getDni() {
		return dni;
	}

	/**
	 * Establece el DNI del usuario.
	 * 
	 * @param dni el DNI del usuario
	 */
	public void setDni(String dni) {
		this.dni = dni;
	}

	/**
	 * Devuelve el nombre del usuario.
	 * 
	 * @return el nombre del usuario
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Establece el nombre del usuario.
	 * 
	 * @param nombre el nombre del usuario
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Devuelve los apellidos del usuario.
	 * 
	 * @return los apellidos del usuario
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * Establece los apellidos del usuario.
	 * 
	 * @param apellidos los apellidos del usuario
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * Devuelve el correo electrónico del usuario.
	 * 
	 * @return el correo electrónico del usuario
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Establece el correo electrónico del usuario.
	 * 
	 * @param email el correo electrónico del usuario
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Devuelve la contraseña del usuario.
	 * 
	 * @return la contraseña del usuario
	 */
	public String getContrasenna() {
		return contrasenna;
	}

	/**
	 * Establece la contraseña del usuario.
	 * 
	 * @param contrasenna la contraseña del usuario
	 */
	public void setContrasenna(String contrasenna) {
		this.contrasenna = contrasenna;
	}

	/**
	 * Devuelve la fecha de nacimiento del usuario.
	 * 
	 * @return la fecha de nacimiento del usuario
	 */
	public LocalDate getFecha_de_nacimiento() {
		return fecha_de_nacimiento;
	}

	/**
	 * Establece la fecha de nacimiento del usuario.
	 * 
	 * @param fecha_de_nacimiento la fecha de nacimiento del usuario en formato String ("yyyy-MM-dd")
	 */
	public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		this.fecha_de_nacimiento = LocalDate.parse(fecha_de_nacimiento, f);
	}

	/**
	 * Devuelve el rol del usuario.
	 * 
	 * @return true si el usuario es administrador, false si es usuario normal
	 */
	public boolean isRol() {
		return rol;
	}

	/**
	 * Establece el rol del usuario.
	 * 
	 * @param rol true si el usuario es administrador, false si es usuario normal
	 */
	public void setRol(boolean rol) {
		this.rol = rol;
	}

	/**
	 * Devuelve el estado del usuario.
	 * 
	 * @return true si el usuario está activo, false si está inactivo
	 */
	public boolean isEstado() {
		return estado;
	}

	/**
	 * Establece el estado del usuario.
	 * 
	 * @param estado true si el usuario está activo, false si está inactivo
	 */
	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	/**
	 * Devuelve una representación en forma de String del usuario.
	 * 
	 * @return una representación en forma de String del usuario
	 */
	@Override
	public String toString() {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return "Usuarios [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", email=" + email
				+ ", contrasenna=" + contrasenna + ", fecha_de_nacimiento=" + f.format(fecha_de_nacimiento) + ", rol=" + rol
				+ ", estado=" + estado + "]";
	}
}
