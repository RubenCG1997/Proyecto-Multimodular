package proyecto;

/**
 * Esta clase representa una editorial de libros.
 */
public class Editoriales {
    
    private String cif;
    private String nombre;
    private String direccion;
    private String telefono;
    private String cp;
    private boolean estado;
    
    /**
     * Constructor por defecto de la clase.
     */
    public Editoriales() {}
    
    /**
     * Constructor con parámetros de la clase.
     * 
     * @param cif El CIF de la editorial.
     * @param nombre El nombre de la editorial.
     * @param direccion La dirección de la editorial.
     * @param telefono El número de teléfono de la editorial.
     * @param cp El código postal de la editorial.
     * @param estado El estado de la editorial.
     */
    public Editoriales(String cif, String nombre, String direccion, String telefono, String cp, boolean estado) {
        super();
        this.cif = cif;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.cp = cp;
        this.estado = estado;
    }

    /**
     * Método getter para obtener el CIF de la editorial.
     * 
     * @return El CIF de la editorial.
     */
    public String getCif() {
        return cif;
    }

    /**
     * Método setter para establecer el CIF de la editorial.
     * 
     * @param cif El nuevo CIF de la editorial.
     */
    public void setCif(String cif) {
        this.cif = cif;
    }

    /**
     * Método getter para obtener el nombre de la editorial.
     * 
     * @return El nombre de la editorial.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método setter para establecer el nombre de la editorial.
     * 
     * @param nombre El nuevo nombre de la editorial.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método getter para obtener la dirección de la editorial.
     * 
     * @return La dirección de la editorial.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Método setter para establecer la dirección de la editorial.
     * 
     * @param direccion La nueva dirección de la editorial.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Método getter para obtener el teléfono de la editorial.
     * 
     * @return El teléfono de la editorial.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Método setter para establecer el teléfono de la editorial.
     * 
     * @param telefono El nuevo teléfono de la editorial.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Método getter para obtener el código postal de la editorial.
     * 
     * @return El código postal de la editorial.
     */
    public String getCp() {
        return cp;
    }

    /**
     * Método setter para establecer el código postal de la editorial.
     * 
     * @param cp El nuevo código postal de la editorial.
     */
    public void setCp(String cp) {
        this.cp = cp;
    }

    /**
     * Método getter para obtener el estado de la editorial.
     * 
     * @return El estado de la editorial.
     */
    public boolean isEstado() {
        return estado;
    }

    /**
     * Método setter para establecer el estado de la editorial.
     * 
     * @param estado El nuevo estado de la editorial.
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * Método que devuelve una representación en forma de cadena de la editorial.
     * 
     * @return Una cadena que representa la editorial.
     */
    @Override
    public String toString() {
        return "Editoriales [cif=" + cif + ", nombre=" + nombre + ", direccion=" + direccion + ", telefono=" + telefono
                + ", cp=" + cp + ", estado=" + estado + "]";
    }

}
