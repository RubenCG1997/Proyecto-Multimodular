package proyecto;

/**
 * Esta clase representa la relación entre una cuenta y una publicación, indicando el porcentaje de la publicación que ha sido leído por la cuenta.
 */
public class CuentaLeePublicacion {
	
	private int pkfkCuenta;
	private String pkfkPublicacion;
	private int porcentaje;
	
	
	/**
	 * Constructor por defecto.
	 */
	public CuentaLeePublicacion() {}

	/**
	 * Constructor que inicializa los atributos de la clase.
	 * @param pkfkCuenta El identificador de la cuenta.
	 * @param pkfkPublicacion El identificador de la publicación.
	 * @param porcentaje El porcentaje de la publicación que ha sido leído.
	 */
	public CuentaLeePublicacion(int pkfkCuenta, String pkfkPublicacion, int porcentaje) {
		this.pkfkCuenta = pkfkCuenta;
		this.pkfkPublicacion = pkfkPublicacion;
		this.porcentaje = porcentaje;
	}

	/**
	 * Obtiene el identificador de la cuenta.
	 * @return El identificador de la cuenta.
	 */
	public int getPkfkCuenta() {
		return pkfkCuenta;
	}

	/**
	 * Establece el identificador de la cuenta.
	 * @param pkfkCuenta El identificador de la cuenta a establecer.
	 */
	public void setPkfkCuenta(int pkfkCuenta) {
		this.pkfkCuenta = pkfkCuenta;
	}

	/**
	 * Obtiene el identificador de la publicación.
	 * @return El identificador de la publicación.
	 */
	public String getPkfkPublicacion() {
		return pkfkPublicacion;
	}

	/**
	 * Establece el identificador de la publicación.
	 * @param pkfkPublicacion El identificador de la publicación a establecer.
	 */
	public void setPkfkPublicacion(String pkfkPublicacion) {
		this.pkfkPublicacion = pkfkPublicacion;
	}

	/**
	 * Obtiene el porcentaje de la publicación leído por la cuenta.
	 * @return El porcentaje de la publicación leído.
	 */
	public int getPorcentaje() {
		return porcentaje;
	}

	/**
	 * Establece el porcentaje de la publicación leído por la cuenta.
	 * @param porcentaje El porcentaje de la publicación a establecer.
	 */
	public void setPorcentaje(int porcentaje) {
		this.porcentaje = porcentaje;
	}

	/**
	 * Retorna una representación en cadena de la clase.
	 * @return Una cadena que representa la cuenta, la publicación y el porcentaje leído.
	 */
	public String toString() {
		return "CuentaLeePublicacion [pkfkCuenta=" + pkfkCuenta + ", pkfkPublicacion=" + pkfkPublicacion
				+ ", porcentaje=" + porcentaje + "]";
	}	
}
