/**
 * 
 */
/**
 * 
 */
module Proyecto3Trimestre {
	requires java.sql;
	requires org.junit.jupiter.api;
}