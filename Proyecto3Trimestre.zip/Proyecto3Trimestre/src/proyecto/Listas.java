package proyecto;

/**
 * Esta clase representa una lista de publicaciones asociada a una cuenta.
 */
public class Listas {

    private String nombre;
    private int pkfkCuenta;
    private boolean estado;
    
    /**
     * Constructor por defecto de la clase.
     */
    public Listas() {}

    /**
     * Constructor con parámetros de la clase.
     * 
     * @param nombre El nombre de la lista.
     * @param pkfkCuenta El identificador de la cuenta asociada a la lista.
     * @param estado El estado de la lista.
     */
    public Listas(String nombre, int pkfkCuenta, boolean estado) {
        this.nombre = nombre;
        this.pkfkCuenta = pkfkCuenta;
        this.estado = estado;
    }

    /**
     * Método getter para obtener el nombre de la lista.
     * 
     * @return El nombre de la lista.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método setter para establecer el nombre de la lista.
     * 
     * @param nombre El nuevo nombre de la lista.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método getter para obtener el identificador de la cuenta asociada a la lista.
     * 
     * @return El identificador de la cuenta asociada a la lista.
     */
    public int getPkfkCuenta() {
        return pkfkCuenta;
    }

    /**
     * Método setter para establecer el identificador de la cuenta asociada a la lista.
     * 
     * @param pkfkCuenta El nuevo identificador de la cuenta asociada a la lista.
     */
    public void setPkfkCuenta(int pkfkCuenta) {
        this.pkfkCuenta = pkfkCuenta;
    }

    /**
     * Método getter para obtener el estado de la lista.
     * 
     * @return El estado de la lista.
     */
    public boolean isEstado() {
        return estado;
    }

    /**
     * Método setter para establecer el estado de la lista.
     * 
     * @param estado El nuevo estado de la lista.
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * Método que devuelve una representación en forma de cadena de la lista.
     * 
     * @return Una cadena que representa la lista.
     */
    @Override
    public String toString() {
        return "Listas [nombre=" + nombre + ", pkfkCuenta=" + pkfkCuenta + ", estado=" + estado + "]";
    }
}
