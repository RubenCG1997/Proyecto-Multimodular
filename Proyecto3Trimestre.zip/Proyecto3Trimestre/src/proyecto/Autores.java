package proyecto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * La clase Autores representa a los autores de publicaciones.
 */
public class Autores {
    
    private String nombre;
    private String apellidos;
    private LocalDate fecha_de_nacimiento;
    private String biografia;
    private boolean estado;
    
    /**
     * Constructor por defecto de la clase Autores.
     */
    public Autores() {}

    /**
     * Constructor de la clase Autores que inicializa los atributos del autor.
     * 
     * @param nombre              El nombre del autor.
     * @param apellidos           Los apellidos del autor.
     * @param fecha_de_nacimiento La fecha de nacimiento del autor en formato de cadena "yyyy-MM-dd".
     * @param biografia           La biografía del autor.
     * @param estado              El estado del autor.
     */
    public Autores(String nombre, String apellidos, String fecha_de_nacimiento, String biografia, boolean estado) {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fecha_de_nacimiento = LocalDate.parse(fecha_de_nacimiento, f);
        this.biografia = biografia;
        this.estado = estado;
    }

    /**
     * Obtiene el nombre del autor.
     * 
     * @return El nombre del autor.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del autor.
     * 
     * @param nombre El nuevo nombre del autor.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene los apellidos del autor.
     * 
     * @return Los apellidos del autor.
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Establece los apellidos del autor.
     * 
     * @param apellidos Los nuevos apellidos del autor.
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * Obtiene la fecha de nacimiento del autor.
     * 
     * @return La fecha de nacimiento del autor.
     */
    public LocalDate getFecha_de_nacimiento() {
        return fecha_de_nacimiento;
    }

    /**
     * Establece la fecha de nacimiento del autor.
     * 
     * @param fecha_de_nacimiento La nueva fecha de nacimiento del autor en formato de cadena "yyyy-MM-dd".
     */
    public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.fecha_de_nacimiento = LocalDate.parse(fecha_de_nacimiento, f);
    }

    /**
     * Obtiene la biografía del autor.
     * 
     * @return La biografía del autor.
     */
    public String getBiografia() {
        return biografia;
    }

    /**
     * Establece la biografía del autor.
     * 
     * @param biografia La nueva biografía del autor.
     */
    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }

    /**
     * Obtiene el estado del autor.
     * 
     * @return El estado del autor.
     */
    public boolean isEstado() {
        return estado;
    }

    /**
     * Establece el estado del autor.
     * 
     * @param estado El nuevo estado del autor.
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * Retorna una representación en cadena del autor.
     * 
     * @return Una cadena que representa al autor.
     */
    @Override
    public String toString() {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return "Autores [nombre=" + nombre + ", apellidos=" + apellidos + ", fecha_de_nacimiento=" + f.format(fecha_de_nacimiento)
                + ", biografia=" + biografia + ", estado=" + estado + "]";
    }
}
