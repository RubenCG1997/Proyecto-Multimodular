package proyecto;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class APPTest {

	 	@Test
	    public void testCrearSuscripcion() {
	        // Crear una suscripción
	        Suscripciones suscripcion = new Suscripciones(Suscripciones.TIPO.FAMILIAR, Suscripciones.CUOTA.ANUAL); 
	        assertEquals(Suscripciones.TIPO.FAMILIAR, suscripcion.getTipo());
	        assertEquals(Suscripciones.CUOTA.ANUAL, suscripcion.getCuota());
	    }
	 	@Test
	 	 public void testCrearSuscripcionConTipoNulo() {
	             // Intentar crear una suscripción con tipo nulo
	             new Suscripciones(null, Suscripciones.CUOTA.MENSUAL);
	             fail("Se esperaba una excepción IllegalArgumentException");
	 	}
	             

	     @Test
	     public void testCrearSuscripcionConCuotaNula() {
	             // Intentar crear una suscripción con cuota nula
	             new Suscripciones(Suscripciones.TIPO.INDIVIDUAL, null);
	             fail("Se esperaba una excepción IllegalArgumentException");
	     }
	 	@Test
	 	public void testCalcularPrecioIndividualMensual() {
	        Suscripciones suscripcion = new Suscripciones(Suscripciones.TIPO.INDIVIDUAL, Suscripciones.CUOTA.MENSUAL);
	        assertEquals(8.99, suscripcion.getPrecio(), 0.01);
	    }

	    @Test
	    public void testCalcularPrecioDuoAnual() {
	        Suscripciones suscripcion = new Suscripciones(Suscripciones.TIPO.DUO, Suscripciones.CUOTA.ANUAL);
	        assertEquals(169.99, suscripcion.getPrecio(), 0.01);
	    }
	 	@Test
	 	public void testCalcularPrecioIndividualMensual_invalid() {
	        Suscripciones suscripcion = new Suscripciones(Suscripciones.TIPO.INDIVIDUAL, Suscripciones.CUOTA.MENSUAL);
	        assertEquals(2.99, suscripcion.getPrecio(), 0.01,"Mal");
	    }

	    @Test
	    public void testCalcularPrecioDuoAnual_invalid() {
	        Suscripciones suscripcion = new Suscripciones(Suscripciones.TIPO.DUO, Suscripciones.CUOTA.ANUAL);
	        assertEquals(23.99, suscripcion.getPrecio(), 0.01,"Mal");
	    }
	    
	    
	    
	    
	    
	 
}
