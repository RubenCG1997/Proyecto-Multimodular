package proyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase proporciona métodos para acceder y manipular la tabla CuentaLeePublicacion en la base de datos.
 */
public class CuentaLeePublicacionDAO {
    private Connection conexion;
    private final String USUARIO = "palProyecto";
    private final String PASSWORD = "123456789";
    private final String MAQUINA = "localhost";
    private final String BD = "proyectofinal";
    
    /**
     * Constructor que inicializa la conexión con la base de datos.
     */
    public CuentaLeePublicacionDAO() {
        this.conexion = conectar();
    }
    
    /**
     * Establece la conexión con la base de datos.
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (SQLException ex) {
            System.out.println("Error al conectar a la base de datos");
        }
        
        return con;
    }
    
    /**
     * Inserta una nueva entrada en la tabla CuentaLeePublicacion.
     * @param clp La cuenta que lee la publicación a insertar.
     */
    public void create(CuentaLeePublicacion clp) {
        if (clp != null) {
            String sql = "INSERT INTO CuentaLeePublicacion (pkfkCuenta, pkfkPublicacion, porcentaje) VALUES (?, ?, ?)";
            
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, clp.getPkfkCuenta());
                sentencia.setString(2, clp.getPkfkPublicacion());
                sentencia.setInt(3, clp.getPorcentaje());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al insertar cuenta lee publicación en la base de datos");
            }
        }
    }
    
    /**
     * Lee una entrada de la tabla CuentaLeePublicacion basada en el identificador de cuenta y el identificador de publicación.
     * @param pkfkCuenta El identificador de cuenta.
     * @param pkfkPublicacion El identificador de publicación.
     * @return La cuenta que lee la publicación encontrada, o null si no se encuentra.
     */
    public CuentaLeePublicacion read(int pkfkCuenta, String pkfkPublicacion) {
        CuentaLeePublicacion clp = null;
        String sql = "SELECT * FROM CuentaLeePublicacion WHERE pkfkCuenta = ? AND pkfkPublicacion = ?";
        
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, pkfkCuenta);
            sentencia.setString(2, pkfkPublicacion);
            
            ResultSet rs = sentencia.executeQuery();
            if (rs.next()) {
                clp = new CuentaLeePublicacion(
                    rs.getInt("pkfkCuenta"),
                    rs.getString("pkfkPublicacion"),
                    rs.getInt("porcentaje")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar cuenta lee publicación");
        }
        return clp;
    }
    
    /**
     * Actualiza una entrada en la tabla CuentaLeePublicacion.
     * @param clp La cuenta que lee la publicación a actualizar.
     */
    public void update(CuentaLeePublicacion clp) {
        if (clp != null) {
            String sql = "UPDATE CuentaLeePublicacion SET porcentaje = ? WHERE pkfkCuenta = ? AND pkfkPublicacion = ?";
            
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, clp.getPorcentaje());
                sentencia.setInt(2, clp.getPkfkCuenta());
                sentencia.setString(3, clp.getPkfkPublicacion());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al actualizar cuenta lee publicación en la base de datos");
            }
        }
    }
    
    /**
     * Elimina una entrada de la tabla CuentaLeePublicacion.
     * @param pkfkCuenta El identificador de cuenta.
     * @param pkfkPublicacion El identificador de publicación.
     */
    public void delete(int pkfkCuenta, String pkfkPublicacion) {
        String sql = "DELETE FROM CuentaLeePublicacion WHERE pkfkCuenta = ? AND pkfkPublicacion = ?";
        
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, pkfkCuenta);
            sentencia.setString(2, pkfkPublicacion);
            sentencia.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al eliminar cuenta lee publicación de la base de datos");
        }
    }
}
